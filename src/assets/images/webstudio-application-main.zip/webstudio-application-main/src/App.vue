<script setup>
  import { RouterView } from 'vue-router'
  import Navbar from "./components/Navbar.vue";
</script>

<template>
  <div>
    <Navbar/>
  </div>
  <RouterView />
</template>


<style scoped>

</style>